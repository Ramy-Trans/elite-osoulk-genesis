import{E as o}from"./index-Bs__WgbD.js";const e=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",e);export{n as C};
